import Error404 from 'views/maintenance/Error404';

// ==============================|| ERROR 404 - MAIN ||============================== //

export default function notfound() {
  return <Error404 />;
}
