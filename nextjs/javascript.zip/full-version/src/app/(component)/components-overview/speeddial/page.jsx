// project-imports
import ComponentSpeeddial from 'views/components-overview/ComponentSpeeddial';

// ==============================|| COMPONENTS - SPEED DIAL ||============================== //

export default function ComponentSpeeddialPage() {
  return <ComponentSpeeddial />;
}
