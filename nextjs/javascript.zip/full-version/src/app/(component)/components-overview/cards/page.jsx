// project-imports
import ComponentCard from 'views/components-overview/ComponentCard';

// ==============================|| COMPONENTS - CARD ||============================== //

export default function ComponentCardPage() {
  return <ComponentCard />;
}
