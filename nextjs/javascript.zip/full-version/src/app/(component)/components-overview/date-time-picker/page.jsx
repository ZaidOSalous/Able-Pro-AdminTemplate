// project-imports
import ComponentDateTimePicker from 'views/components-overview/ComponentDateTimePicker';

// ===============================|| COMPONENTS - DATE / TIME PICKER ||=============================== //

export default function ComponentDateTimePickerPage() {
  return <ComponentDateTimePicker />;
}
