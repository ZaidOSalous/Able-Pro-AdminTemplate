// project-imports
import ComponentAccordion from 'views/components-overview/ComponentAccordion';

// ==============================|| COMPONENTS - ACCORDION ||============================== //

export default function ComponentAccordionPage() {
  return <ComponentAccordion />;
}
