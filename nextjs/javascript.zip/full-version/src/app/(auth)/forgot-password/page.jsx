// project-imports
import ForgotPassword from 'views/authentication/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

export default function ForgotPasswordPage() {
  return <ForgotPassword />;
}
