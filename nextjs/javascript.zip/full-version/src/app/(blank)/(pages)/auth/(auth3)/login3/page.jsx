// project-imports
import Login3Page from 'views/auth/auth3/Login';

// ================================|| LOGIN ||================================ //

export default function Login3() {
  return <Login3Page />;
}
