// project-imports
import RegisterPage from 'views/auth/auth2/Register';

// ================================|| REGISTER ||================================ //

export default function Register() {
  return <RegisterPage />;
}
