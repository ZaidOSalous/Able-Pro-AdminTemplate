// project-imports
import CheckMailPage from 'views/auth/auth1/CheckMail';

// ================================|| CHECK MAIL ||================================ //

export default function CheckMail() {
  return <CheckMailPage />;
}
