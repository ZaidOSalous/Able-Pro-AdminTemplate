// project-imports
import ResetPasswordPage from 'views/auth/auth1/ResetPassword';

// ================================|| RESET PASSWORD ||================================ //

export default function ResetPassword() {
  return <ResetPasswordPage />;
}
