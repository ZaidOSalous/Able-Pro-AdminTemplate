// project-imports
import ForgotPasswordPage from 'views/auth/auth1/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

export default function ForgotPassword() {
  return <ForgotPasswordPage />;
}
