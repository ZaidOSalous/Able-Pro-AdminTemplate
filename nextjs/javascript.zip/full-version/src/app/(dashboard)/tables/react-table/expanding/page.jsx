// project-imports
import ExpandingTables from 'views/forms-tables/tables/react-table/ExpandingTables';

// ==============================|| REACT TABLE - EXPANDING ||============================== //

export default function Expanding() {
  return <ExpandingTables />;
}
