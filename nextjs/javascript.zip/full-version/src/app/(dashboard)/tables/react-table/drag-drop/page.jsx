// project-imports
import DragDropTable from 'views/forms-tables/tables/react-table/DragDropTable';

// ==============================|| REACT TABLE - DRAG & DROP ||============================== //

export default function DragDrop() {
  return <DragDropTable />;
}
