// project-imports
import CustomersCard from 'views/apps/CustomersCard';

// ==============================|| CUSTOMER - CARD ||============================== //

export default function CustomerCardPage() {
  return <CustomersCard />;
}
