// project-imports
import InvoiceCreate from 'views/apps/InvoiceCreate';

// ==============================|| INVOICE - CREATE ||============================== //

export default function Create() {
  return <InvoiceCreate />;
}
