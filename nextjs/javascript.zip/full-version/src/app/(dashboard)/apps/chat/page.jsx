// project-imports
import Chat from 'views/apps/Chat';

// ==============================|| APPLICATION - CHAT ||============================== //

export default function ChatPage() {
  return <Chat />;
}
