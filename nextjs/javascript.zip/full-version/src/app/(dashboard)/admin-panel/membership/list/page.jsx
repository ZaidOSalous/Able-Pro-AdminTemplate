// project-imports
import MembershipList from 'views/admin-panel/membership/MembershipList';

// ==============================|| MEMBERSHIP - LIST ||============================== //

export default function List() {
  return <MembershipList />;
}
