// project-imports
import SettingPrice from 'views/admin-panel/online-courses/setting/SettingPricing';

// ==============================|| SETTING - PRICE ||============================== //

export default function Price() {
  return <SettingPrice />;
}
