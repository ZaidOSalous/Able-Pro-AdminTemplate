// project-imports
import CoursesView from 'views/admin-panel/online-courses/courses/CoursesView';

// ==============================|| COURSES - VIEW ||============================== //

export default function View() {
  return <CoursesView />;
}
