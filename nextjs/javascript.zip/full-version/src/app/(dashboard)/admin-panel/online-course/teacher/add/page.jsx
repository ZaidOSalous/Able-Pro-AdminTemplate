// project-imports
import TeacherAdd from 'views/admin-panel/online-courses/teacher/TeacherAdd';

// ==============================|| TEACHER - ADD ||============================== //

export default function Add() {
  return <TeacherAdd />;
}
