// project-imports
import StudentAdd from 'views/admin-panel/online-courses/student/StudentAdd';

// ==============================|| STUDENT - ADD ||============================== //

export default function Add() {
  return <StudentAdd />;
}
