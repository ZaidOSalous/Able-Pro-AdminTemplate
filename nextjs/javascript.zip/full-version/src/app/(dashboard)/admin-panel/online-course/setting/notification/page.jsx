// project-imports
import SettingNotification from 'views/admin-panel/online-courses/setting/SettingNotification';

// ==============================|| SETTING - NOTIFICATION ||============================== //

export default function Notification() {
  return <SettingNotification />;
}
