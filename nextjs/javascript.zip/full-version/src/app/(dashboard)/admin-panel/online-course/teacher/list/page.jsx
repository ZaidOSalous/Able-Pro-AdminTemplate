// project-imports
import TeacherList from 'views/admin-panel/online-courses/teacher/TeacherList';

// ==============================|| TEACHER - LIST ||============================== //

export default function List() {
  return <TeacherList />;
}
