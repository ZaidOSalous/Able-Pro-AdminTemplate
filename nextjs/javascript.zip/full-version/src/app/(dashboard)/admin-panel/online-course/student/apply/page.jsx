// project-imports
import StudentApply from 'views/admin-panel/online-courses/student/StudentApplied';

// ==============================|| STUDENT - APPLIED ||============================== //

export default function Apply() {
  return <StudentApply />;
}
