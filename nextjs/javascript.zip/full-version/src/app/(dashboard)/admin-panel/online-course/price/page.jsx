// project-imports
import OnlinePrice from 'views/admin-panel/online-courses/pricing/OnlinePrice';

// ==============================|| ONLINE COURSES - PRICE ||============================== //

export default function Price() {
  return <OnlinePrice />;
}
