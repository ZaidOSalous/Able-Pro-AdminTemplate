// project-imports
import CreateTicket from 'views/admin-panel/helpdesk/ticket/CreateTicket';

// ==============================|| HELPDESK TICKET - CREATE ||============================== //

export default function Create() {
  return <CreateTicket />;
}
