// project-imports
import HelpDeskCustomer from 'views/admin-panel/helpdesk/HelpDeskCustomer';

// ==============================|| HELPDESK - CUSTOMER ||============================== //

export default function Customer() {
  return <HelpDeskCustomer />;
}
