// project-imports
import EditorPage from 'views/forms-tables/forms/plugins/EditorPage';

// ==============================|| PLUGIN - EDITOR ||============================== //

export default function Editor() {
  return <EditorPage />;
}
