// project-imports
import RecaptchaPage from 'views/forms-tables/forms/plugins/RecaptchaPage';

// ==============================|| PLUGIN - RECAPTCHA ||============================== //

export default function Recaptcha() {
  return <RecaptchaPage />;
}
