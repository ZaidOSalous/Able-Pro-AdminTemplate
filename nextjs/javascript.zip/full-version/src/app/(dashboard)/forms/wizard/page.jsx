// project-imports
import FormsWizardPage from 'views/forms-tables/forms/FormsWizard';

// ==============================|| FORMS WIZARD ||============================== //

export default function FormsWizard() {
  return <FormsWizardPage />;
}
