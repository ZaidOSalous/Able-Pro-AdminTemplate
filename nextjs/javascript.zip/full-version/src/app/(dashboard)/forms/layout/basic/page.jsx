// project-imports
import BasicLayouts from 'views/forms-tables/forms/layout/BasicLayouts';

// ==============================|| LAYOUTS - BASIC ||============================== //

export default function Layouts() {
  return <BasicLayouts />;
}
