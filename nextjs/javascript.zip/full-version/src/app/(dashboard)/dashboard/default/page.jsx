// project-imports
import DashboardDefault from 'views/dashboard/DashboardDefault';

// ==============================|| DASHBOARD - DEFAULT ||============================== //

export default function Dashboard() {
  return <DashboardDefault />;
}
