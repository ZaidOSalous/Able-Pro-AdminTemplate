// project-imports
import ComponentSnackbar from 'views/components-overview/ComponentSnackbar';

// ==============================|| COMPONENTS - SNACKBAR ||============================== //

export default function ComponentSnackbarPage() {
  return <ComponentSnackbar />;
}
