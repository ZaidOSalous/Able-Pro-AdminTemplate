// project-imports
import ComponentProgress from 'views/components-overview/ComponentProgress';

// ==============================|| COMPONENTS - PROGRESS ||============================== //

export default function ComponentProgressPage() {
  return <ComponentProgress />;
}
