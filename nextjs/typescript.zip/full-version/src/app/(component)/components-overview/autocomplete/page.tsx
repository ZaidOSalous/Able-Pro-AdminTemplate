// project-imports
import ComponentAutocomplete from 'views/components-overview/ComponentAutocomplete';

// ==============================|| COMPONENTS - AUTOCOMPLETE ||============================== //

export default function ComponentAutocompletePage() {
  return <ComponentAutocomplete />;
}
