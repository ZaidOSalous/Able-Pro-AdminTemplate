// project-imports
import ComponentSelect from 'views/components-overview/ComponentSelect';

// ==============================|| COMPONENTS - SELECT ||============================== //

export default function ComponentSelectPage() {
  return <ComponentSelect />;
}
