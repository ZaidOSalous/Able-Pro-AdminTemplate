// project-imports
import ComponentTreeView from 'views/components-overview/ComponentTreeView';

// ==============================|| COMPONENTS - TREE VIEW ||============================== //

export default function ComponentTreeViewPage() {
  return <ComponentTreeView />;
}
