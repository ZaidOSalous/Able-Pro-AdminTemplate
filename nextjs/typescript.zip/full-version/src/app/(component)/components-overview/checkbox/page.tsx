// project-imports
import ComponentCheckbox from 'views/components-overview/ComponentCheckbox';

// ==============================|| COMPONENTS - CHECKBOX ||============================== //

export default function ComponentCheckboxPage() {
  return <ComponentCheckbox />;
}
