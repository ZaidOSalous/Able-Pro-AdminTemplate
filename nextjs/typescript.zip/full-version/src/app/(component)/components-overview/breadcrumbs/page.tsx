// project-imports
import ComponentBreadcrumb from 'views/components-overview/ComponentBreadcrumb';

// ==============================|| COMPONENTS - BREADCRUMBS ||============================== //

export default function ComponentBreadcrumbPage() {
  return <ComponentBreadcrumb />;
}
