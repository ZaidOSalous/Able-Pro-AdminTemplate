// project-imports
import ComponentShadow from 'views/components-overview/ComponentShadow';

// ============================|| COMPONENTS - SHADOW ||============================ //

export default function ComponentShadowPage() {
  return <ComponentShadow />;
}
