// project-imports
import ComponentTimeline from 'views/components-overview/ComponentTimeline';

// ==============================|| COMPONENTS - TIMELINE ||============================== //

export default function ComponentTimelinePage() {
  return <ComponentTimeline />;
}
