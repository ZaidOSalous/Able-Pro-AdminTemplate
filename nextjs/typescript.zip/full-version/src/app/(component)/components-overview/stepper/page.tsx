// project-imports
import ComponentStepper from 'views/components-overview/ComponentStepper';

// ==============================|| COMPONENTS - STEPPER ||============================== //

export default function ComponentStepperPage() {
  return <ComponentStepper />;
}
