// project-imports
import ComponentRating from 'views/components-overview/ComponentRating';

// ==============================|| COMPONENTS - RATING ||============================== //

export default function ComponentRatingPage() {
  return <ComponentRating />;
}
