// project-imports
import ComponentSlider from 'views/components-overview/ComponentSlider';

// ==============================|| COMPONENTS - SLIDER ||============================== //

export default function ComponentSliderPage() {
  return <ComponentSlider />;
}
