// project-imports
import ComponentSwitch from 'views/components-overview/ComponentSwitch';

// ==============================|| COMPONENTS - SWITCH ||============================== //

export default function ComponentSwitchPage() {
  return <ComponentSwitch />;
}
