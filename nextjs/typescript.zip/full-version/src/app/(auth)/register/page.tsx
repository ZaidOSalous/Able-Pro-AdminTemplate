// project-imports
import Register from 'views/authentication/Register';

// ================================|| REGISTER ||================================ //

export default function RegisterPage() {
  return <Register />;
}
