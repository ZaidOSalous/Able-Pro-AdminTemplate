// project-imports
import Login from 'views/authentication/Login';

// ================================|| LOGIN ||================================ //

export default function LoginPage() {
  return <Login />;
}
