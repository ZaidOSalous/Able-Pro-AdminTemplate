// project-imports
import Error500Page from 'views/maintenance/Error500';

// ==============================|| ERROR 500 ||============================== //

export default function Error500() {
  return <Error500Page />;
}
