// project-imports
import Login2Page from 'views/auth/auth2/Login';

// ================================|| LOGIN ||================================ //

export default function Login2() {
  return <Login2Page />;
}
