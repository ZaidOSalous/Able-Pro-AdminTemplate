// project-imports
import RegisterPage from 'views/auth/auth1/Register';

// ================================|| REGISTER ||================================ //

export default function Register() {
  return <RegisterPage />;
}
