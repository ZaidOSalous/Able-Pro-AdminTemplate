// project-imports
import OrgChartPage from 'views/charts/OrgChart';

// ==============================|| ORGANIZATION CHARTS ||============================== //

export default function OrgChart() {
  return <OrgChartPage />;
}
