// project-imports
import Pricing1Page from 'views/price/Pricing1';

// ==============================|| PRICING ||============================== //

export default function Pricing() {
  return <Pricing1Page />;
}
