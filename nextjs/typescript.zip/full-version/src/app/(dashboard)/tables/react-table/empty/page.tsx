// project-imports
import EmptyTables from 'views/forms-tables/tables/react-table/EmptyTable';

// ==============================|| REACT TABLE - EMPTY ||============================== //

export default function EmptyTableDemo() {
  return <EmptyTables />;
}
