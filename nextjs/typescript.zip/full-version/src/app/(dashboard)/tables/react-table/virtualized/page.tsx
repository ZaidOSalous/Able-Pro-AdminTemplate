// project-imports
import VirtualizedTable from 'views/forms-tables/tables/react-table/VirtualizedTable';

// ==============================|| REACT TABLE - VIRTUALIZED ||============================== //

export default function Virtualized() {
  return <VirtualizedTable />;
}
