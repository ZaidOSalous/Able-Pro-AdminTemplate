// project-imports
import FilteringTable from 'views/forms-tables/tables/react-table/FilteringTable';

// ==============================|| REACT TABLE - FILTERING ||============================== //

export default function Filtering() {
  return <FilteringTable />;
}
