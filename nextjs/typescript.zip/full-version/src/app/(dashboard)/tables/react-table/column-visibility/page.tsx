// project-imports
import ColumnVisibilityTable from 'views/forms-tables/tables/react-table/ColumnVisibilityTable';

// ==============================|| REACT TABLE - COLUMN VISIBILITY ||============================== //

export default function ColumnVisibility() {
  return <ColumnVisibilityTable />;
}
