// project-imports
import UmbrellaTable from 'views/forms-tables/tables/react-table/UmbrellaTable';

// ==============================|| REACT TABLE - UMBRELLA ||============================== //

export default function Umbrella() {
  return <UmbrellaTable />;
}
