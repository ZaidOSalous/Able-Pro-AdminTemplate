// project-imports
import SortingTable from 'views/forms-tables/tables/react-table/SortingTable';

// ==============================|| REACT TABLE - SORTING ||============================== //

export default function Sorting() {
  return <SortingTable />;
}
