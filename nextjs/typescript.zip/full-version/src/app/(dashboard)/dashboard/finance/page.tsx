// project-imports
import DashboardFinance from 'views/dashboard/DashboardFinance';

// ==============================|| DASHBOARD - DEFAULT ||============================== //

export default function Finance() {
  return <DashboardFinance />;
}
