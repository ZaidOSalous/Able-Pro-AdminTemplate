// project-imports
import WidgetStatistics from 'views/widget/WidgetStatistics';

// ===========================|| WIDGET - STATISTICS ||=========================== //

export default function Statistics() {
  return <WidgetStatistics />;
}
