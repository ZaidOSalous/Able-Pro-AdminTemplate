// project-imports
import SamplePagePage from 'views/other/SamplePage';

// ==============================|| SAMPLE PAGE ||============================== //

export default function SamplePage() {
  return <SamplePagePage />;
}
