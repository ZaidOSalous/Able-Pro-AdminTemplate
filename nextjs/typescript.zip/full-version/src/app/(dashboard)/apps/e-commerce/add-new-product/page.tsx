// project-imports
import AddNewProduct from 'views/apps/AddNewProduct';

// ==============================|| ECOMMERCE - ADD PRODUCT ||============================== //

export default function AddNewProductPage() {
  return <AddNewProduct />;
}
