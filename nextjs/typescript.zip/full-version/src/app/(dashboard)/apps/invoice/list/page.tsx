// project-imports
import InvoiceLists from 'views/apps/InvoiceList';

// ==============================|| INVOICE - LIST ||============================== //

export default function List() {
  return <InvoiceLists />;
}
