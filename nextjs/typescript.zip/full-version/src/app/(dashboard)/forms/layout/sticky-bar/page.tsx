// project-imports
import StickyActionBarPage from 'views/forms-tables/forms/layout/StickyActionBar';

// ==============================|| LAYOUTS - STICKY ACTION BAR ||============================== //

export default function StickyActionBar() {
  return <StickyActionBarPage />;
}
