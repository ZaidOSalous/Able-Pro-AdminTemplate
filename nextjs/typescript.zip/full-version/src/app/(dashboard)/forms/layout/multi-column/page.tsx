// project-imports
import ColumnsLayoutsPage from 'views/forms-tables/forms/layout/ColumnsLayouts';

// ==============================|| LAYOUTS -  COLUMNS ||============================== //

export default function ColumnsLayouts() {
  return <ColumnsLayoutsPage />;
}
