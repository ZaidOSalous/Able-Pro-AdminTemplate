// project-imports
import OnlineSite from 'views/admin-panel/online-courses/site/OnlineSite';

// ==============================|| ONLINE COURSES - SITE ||============================== //

export default function Site() {
  return <OnlineSite />;
}
