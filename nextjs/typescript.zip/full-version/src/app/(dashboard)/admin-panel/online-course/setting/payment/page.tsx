// project-imports
import SettingPayment from 'views/admin-panel/online-courses/setting/SettingPayment';

// ==============================|| SETTING - PAYMENT ||============================== //

export default function Payment() {
  return <SettingPayment />;
}
