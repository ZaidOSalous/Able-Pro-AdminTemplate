// project-imports
import StudentList from 'views/admin-panel/online-courses/student/StudentList';

// ==============================|| STUDENT - LIST ||============================== //

export default function List() {
  return <StudentList />;
}
