// project-imports
import TeacherApply from 'views/admin-panel/online-courses/teacher/TeacherApplied';

// ==============================|| TEACHER - APPLIED ||============================== //

export default function Apply() {
  return <TeacherApply />;
}
