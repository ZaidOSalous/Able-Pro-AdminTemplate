// project-imports
import OnlineCoursesDashboard from 'views/admin-panel/online-courses/dashboard/OnlineDashboard';

// ==============================|| ONLINE COURSES - DASHBOARD ||============================== //

export default function Dashboard() {
  return <OnlineCoursesDashboard />;
}
