// project-imports
import CoursesAdd from 'views/admin-panel/online-courses/courses/CoursesAdd';

// ==============================|| COURSES - ADD ||============================== //

export default function Add() {
  return <CoursesAdd />;
}
