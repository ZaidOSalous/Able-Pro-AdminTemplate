// project-imports
import HelpDeskDashboard from 'views/admin-panel/helpdesk/HelpDeskDashboard';

// ==============================|| HELPDESK - DASHBOARD ||============================== //

export default function Dashboard() {
  return <HelpDeskDashboard />;
}
