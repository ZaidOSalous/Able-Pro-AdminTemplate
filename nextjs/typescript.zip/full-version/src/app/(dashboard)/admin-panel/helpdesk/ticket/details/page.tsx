// project-imports
import TicketDetails from 'views/admin-panel/helpdesk/ticket/TicketDetails';

// ==============================|| HELPDESK TICKET - DETAILS ||============================== //

export default function Details() {
  return <TicketDetails />;
}
