// project-imports
import TicketList from 'views/admin-panel/helpdesk/ticket/TicketList';

// ==============================|| HELPDESK TICKET - LIST ||============================== //

export default function List() {
  return <TicketList />;
}
