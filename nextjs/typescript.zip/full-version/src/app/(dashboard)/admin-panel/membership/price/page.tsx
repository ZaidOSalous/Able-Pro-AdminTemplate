// project-imports
import MembershipPrice from 'views/admin-panel/membership/MembershipPrice';

// ==============================|| MEMBERSHIP - PRICE ||============================== //

export default function Price() {
  return <MembershipPrice />;
}
