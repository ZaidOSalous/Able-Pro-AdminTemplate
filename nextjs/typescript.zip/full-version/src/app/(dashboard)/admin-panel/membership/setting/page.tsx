// project-imports
import MembershipSetting from 'views/admin-panel/membership/MembershipSetting';

// ==============================|| MEMBERSHIP - SETTING ||============================== //

export default function Setting() {
  return <MembershipSetting />;
}
