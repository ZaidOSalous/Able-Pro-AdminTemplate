// project-imports
import MembershipDashboard from 'views/admin-panel/membership/MembershipDashboard';

// ==============================|| MEMBERSHIP - DASHBOARD ||============================== //

export default function Dashboard() {
  return <MembershipDashboard />;
}
